import React, { useEffect, useState } from 'react';
import * as signalR from '@microsoft/signalr';

function App() {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const connection = new signalR.HubConnectionBuilder()
      .withUrl("https://localhost:7237/messageHub") // make sure port matches your API
      .withAutomaticReconnect()
      .build();

    connection.on("ReceiveMessage", (message) => {
      setMessages(prev => [...prev, message]);
    });

    connection.start()
      .then(() => console.log("✅ Connected to SignalR hub"))
      .catch(err => console.error(" SignalR connection error:", err));

    return () => {
      connection.stop();
    };
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>Live Service Bus Messages</h2>
      <ul>
        {messages.map((msg, i) => <li key={i}>{msg}</li>)}
      </ul>
    </div>
  );
}

export default App;
