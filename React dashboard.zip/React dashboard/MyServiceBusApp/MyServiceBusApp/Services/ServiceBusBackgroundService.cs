﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.SignalR;
using MyServiceBusApp.Hubs;

public class ServiceBusBackgroundService : BackgroundService
{
    private readonly IConfiguration _config;
    private readonly IHubContext<MessageHub> _hubContext;
    private ServiceBusProcessor _processor;

    public ServiceBusBackgroundService(IConfiguration config, IHubContext<MessageHub> hubContext)
    {

        _config = config;
        _hubContext = hubContext;

        var client = new ServiceBusClient(_config["AzureServiceBus:ConnectionString"]);
        _processor = client.CreateProcessor(
            _config["AzureServiceBus:TopicName"],
            _config["AzureServiceBus:SubscriptionName"],
            new ServiceBusProcessorOptions
            {
                AutoCompleteMessages = false // We manually complete after sending to SignalR
            });
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _processor.ProcessMessageAsync += OnMessageReceived;
        _processor.ProcessErrorAsync += OnError;

        await _processor.StartProcessingAsync(stoppingToken);
    }

    private async Task OnMessageReceived(ProcessMessageEventArgs args)
    {
        try
        {
            var body = args.Message.Body.ToString();
            Console.WriteLine($" Received from Service Bus: {body}");

            // Broadcast to all connected SignalR clients
            await _hubContext.Clients.All.SendAsync("ReceiveMessage", body);

            // Mark message as completed
            await args.CompleteMessageAsync(args.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine($" Error processing message: {ex.Message}");
        }
    }

    private Task OnError(ProcessErrorEventArgs args)
    {
        Console.WriteLine($" Service Bus Error: {args.Exception.Message}");
        return Task.CompletedTask;
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await _processor.StopProcessingAsync();
        await _processor.DisposeAsync();
        await base.StopAsync(cancellationToken);
    }
}
