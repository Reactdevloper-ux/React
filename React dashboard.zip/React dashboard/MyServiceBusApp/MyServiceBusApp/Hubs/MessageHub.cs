﻿using Microsoft.AspNetCore.SignalR;

namespace MyServiceBusApp.Hubs
{
    public class MessageHub : Hub
    {
    }
}
