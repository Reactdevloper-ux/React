﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace MyServiceBusApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MessageController : ControllerBase
    {
        private readonly ServiceBusSender _sender;

        public MessageController(IConfiguration config)
        {
            var client = new ServiceBusClient(config["AzureServiceBus:ConnectionString"]);
            _sender = client.CreateSender(config["AzureServiceBus:TopicName"]);
        }

        [HttpPost]
        public async Task<IActionResult> SendMessage([FromBody] string message)
        {
            await _sender.SendMessageAsync(new ServiceBusMessage(message));
            return Ok("Message sent to topic.");
        }
    }
}